def power(a,b):
    return a**b
print(power(3,2))
